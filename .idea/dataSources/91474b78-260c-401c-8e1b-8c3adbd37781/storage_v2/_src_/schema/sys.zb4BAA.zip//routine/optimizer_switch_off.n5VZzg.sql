create
    definer = `mariadb.sys`@localhost procedure optimizer_switch_off()
    comment 'return @@optimizer_switch options that are off'
    sql security invoker
BEGIN
  call optimizer_switch_choice("off");
END;

